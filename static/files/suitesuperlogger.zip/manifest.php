<?php
$manifest = array(
		'acceptable_sugar_flavors' => array(
				'CE', 'PRO' ,'ENT'
		),
		'acceptable_sugar_versions' =>  array (
				'regex_matches' => array (
						'6\.*',
				),
		),
		'readme' => '',
		'key' => 'JSMCL',
		'author' => 'Jim Mackin',
		'description' => 'Improved logging for SuiteCRM',
		'is_uninstallable' => true,
		'name' => 'SuiteCRM Super Logger',
		'published_date' => '2015-08-12',
		'type' => 'module',
		'version' => '1.1',

);

$installdefs = array(
		'id'            => 'JSMCL',
		'copy' => array(
				array(
						'from'        => '<basepath>/SuiteSuperLogger.php',
						'to'          => 'custom/include/SugarLogger/SuiteSuperLogger.php',
				),
		),
);